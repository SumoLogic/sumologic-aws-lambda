import re

import boto3


def regexmatch():
    regex = "[\"']InstanceType[\"']:\s{0,2}[\"']t1.micro.*?[\"']|[\"']name[\"']:\s{0,2}[\"']Test.*?[\"']"
    pattern = re.compile(regex)

    client = boto3.client('ec2', region_name="us-east-1")
    data = client.describe_instances(MaxResults=1000)
    for reservation in data['Reservations']:
        if "Instances" in reservation:
            for instance in reservation["Instances"]:
                matcher = pattern.search(str(instance))
                if matcher:
                    print(instance['InstanceId'])
                else:
                    print("no Match")

    client = boto3.client('dynamodb', region_name="us-east-1")
    data = client.list_tables(Limit=100)
    if "TableNames" in data:
        for table in data["TableNames"]:
            matcher = pattern.search(str(table))
            if matcher:
                print(table)
            else:
                print("no Match")


if __name__ == '__main__':
    regexmatch()
