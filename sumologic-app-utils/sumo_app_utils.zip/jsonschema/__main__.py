"""
The jsonschema CLI is now deprecated in favor of check-jsonschema.
"""
from jsonschema.cli import main

main()
