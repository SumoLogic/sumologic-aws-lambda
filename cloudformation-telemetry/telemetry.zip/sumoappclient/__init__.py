import sys
import os

cur_dir = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, cur_dir)
