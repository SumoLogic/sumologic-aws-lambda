# $PACKAGENAME

Solution to pull alerts from $APPNAME to Sumo Logic


## Installation

This collector can be deployed both onprem and on cloud.


